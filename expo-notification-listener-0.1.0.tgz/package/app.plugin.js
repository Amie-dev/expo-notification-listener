module.exports = require('./plugin/build/index.js').default;
